﻿namespace WebApplication3.Models
{
    public class CurrencyRate
    {
        public string BaseCurrency { get; set; }
        public Dictionary<string, decimal> Rates { get; set; }
    }

}
