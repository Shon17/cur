﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Services;

namespace WebApplication3.Controllers
{
    public class CurrencyController : Controller
    {
        public async Task<ActionResult> Index()
        {
            var model = await CurrencyApiHelper.GetCurrencyRatesAsync("USD"); // Default to USD
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> Convert(string baseCurrency, string targetCurrency, decimal amount)
        {
            var rates = await CurrencyApiHelper.GetCurrencyRatesAsync(baseCurrency);
            var rate = rates.Rates[targetCurrency];
            var convertedAmount = amount * rate;
            ViewBag.BaseCurrency = baseCurrency;
            ViewBag.TargetCurrency = targetCurrency;
            ViewBag.OriginalAmount = amount;
            ViewBag.ConvertedAmount = convertedAmount;
            return View("Index", rates);

        }
    }

}
