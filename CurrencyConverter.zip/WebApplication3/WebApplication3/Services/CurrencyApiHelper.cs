﻿using Newtonsoft.Json;
using WebApplication3.Models;

namespace WebApplication3.Services
{
    public static class CurrencyApiHelper
    {
        private const string ApiUrl = "https://api.exchangerate-api.com/v4/latest/{0}"; 
        private const string ApiKey = " ffba9db6898edefb48db6d56"; 

        public static async Task<CurrencyRate> GetCurrencyRatesAsync(string baseCurrency)
        {
            var client = new HttpClient();
            var requestUrl = string.Format(ApiUrl, baseCurrency) + $"?apiKey={ApiKey}";
            var response = await client.GetStringAsync(requestUrl);
            var rates = JsonConvert.DeserializeObject<CurrencyRate>(response);
            return rates;
        }

    }

}
